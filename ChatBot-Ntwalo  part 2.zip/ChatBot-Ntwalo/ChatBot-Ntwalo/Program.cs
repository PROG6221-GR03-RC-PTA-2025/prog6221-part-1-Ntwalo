﻿using System;
using System.Collections.Generic;
using System.Media;
using System.Threading;

namespace CybersecurityAwarenessBot
{
    class Program
    {
        static Dictionary<string, string> keywordResponses = new Dictionary<string, string>
        {
            { "password", "Make sure to use strong, unique passwords for each account. Avoid using personal details in your passwords." },
            { "scam", "Always verify emails and links before clicking. Scammers often disguise themselves as trusted organizations." },
            { "privacy", "Keep your personal data secure by reviewing your privacy settings regularly and using encrypted communication tools." }
        };

        static List<string> phishingTips = new List<string>
        {
            "Be cautious of emails asking for personal information. Scammers often disguise themselves as trusted organizations.",
            "Look for grammatical errors or suspicious sender addresses—these can indicate phishing scams.",
            "Never click on unknown links. Always verify with the official website before taking action."
        };

        static Dictionary<string, string> sentimentResponses = new Dictionary<string, string>
        {
            { "worried", "It's understandable to feel that way. Let's discuss some safety tips." },
            { "curious", "Great curiosity! Let me explain further." },
            { "frustrated", "I know cybersecurity can be complex, but I'm here to help. Let’s break it down together." }
        };

        static Dictionary<string, string> userMemory = new Dictionary<string, string>();
        static string currentTopic = "";
        static Random random = new Random();

        static void Main(string[] args)
        {
            PlayVoiceGreeting();
            DisplayAsciiArt();
            string userName = GreetUser();

            bool isRunning = true;
            while (isRunning)
            {
                Console.ForegroundColor = ConsoleColor.Cyan;
                Console.WriteLine("\nWhat would you like to ask about?");
                Console.WriteLine("1. How are you?");
                Console.WriteLine("2. What’s your purpose?");
                Console.WriteLine("3. What can I ask you about?");
                Console.WriteLine("4. Learn about Phishing Emails");
                Console.WriteLine("5. Learn about Password Safety");
                Console.WriteLine("6. Learn about Recognizing Suspicious Links");
                Console.WriteLine("7. Exit");
                Console.ResetColor();

                Console.Write("\nEnter your choice (1-7): ");
                string userInput = Console.ReadLine();

                ProcessUserInput(userInput, userName, ref isRunning);
            }
        }

        static void PlayVoiceGreeting()
        {
            try
            {
                using (SoundPlayer player = new SoundPlayer(@"voice_greeting.wav"))
                {
                    player.PlaySync();
                }
            }
            catch (Exception)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Voice greeting could not be played. Please check the file path.");
                Console.ResetColor();
            }
        }

        static void DisplayAsciiArt()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(@"
   _____            _                       _   _             
  / ____|          | |                     | | (_)            
 | |     ___  _ __ | |_ ___  _ __ ___   ___| |_ _  ___  _ __  
 | |    / _ \| '_ \| __/ _ \| '_ ` _ \ / _ \ __| |/ _ \| '_ \ 
 | |___| (_) | | | | || (_) | | | | | |  __/ |_| | (_) | | | |
  \_____\___/|_| |_|\__\___/|_| |_| |_|\___|\__|_|\___/|_| |_|
");
            Console.ResetColor();
        }

        static string GreetUser()
        {
            Console.Write("\nWhat’s your name? ");
            string name = Console.ReadLine();
            if (string.IsNullOrWhiteSpace(name))
                name = "User";

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"\nHello, {name}! Welcome to the Cybersecurity Awareness Bot.");
            Console.WriteLine("I’m here to help you learn about staying safe online.");
            Console.ResetColor();

            return name;
        }

        static void Respond(string message)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            foreach (char c in message)
            {
                Console.Write(c);
                Thread.Sleep(50);
            }
            Console.WriteLine();
            Console.ResetColor();
        }

        static void ProcessUserInput(string input, string userName, ref bool isRunning)
        {
            if (keywordResponses.ContainsKey(input.ToLower()))
            {
                Respond(keywordResponses[input.ToLower()]);
                return;
            }

            DetectSentiment(input);
            HandleConversationFlow(input);

            switch (input)
            {
                case "1":
                    Respond($"I’m just a chatbot, {userName}, but I’m functioning perfectly and here to help you!");
                    break;
                case "2":
                    Respond("My purpose is to educate you on cybersecurity awareness and help you stay safe online.");
                    break;
                case "3":
                    Respond("You can ask me about phishing emails, creating strong passwords, or recognizing suspicious links.");
                    break;
                case "4":
                    DisplayPhishingTip();
                    break;
                case "5":
                    DisplayPasswordInfo();
                    break;
                case "6":
                    DisplayLinkInfo();
                    break;
                case "7":
                    Respond($"Thank you for chatting with me, {userName}. Stay safe online, and have a great day!");
                    isRunning = false;
                    break;
                default:
                    HandleUnknownInput(input);
                    break;
            }
        }

        static void DisplayPhishingTip()
        {
            int index = random.Next(phishingTips.Count);
            Respond(phishingTips[index]);
        }

        static void DisplayPasswordInfo()
        {
            Respond("Strong passwords help protect your online accounts. Use a mix of letters, numbers, and special characters!");
        }

        static void DisplayLinkInfo()
        {
            Respond("Cybercriminals use deceptive links to trick you into visiting malicious sites. Hover over links before clicking!");
        }

        static void DetectSentiment(string input)
        {
            foreach (var sentiment in sentimentResponses.Keys)
            {
                if (input.ToLower().Contains(sentiment))
                {
                    Respond(sentimentResponses[sentiment]);
                    return;
                }
            }
        }

        static void HandleConversationFlow(string input)
        {
            if (input.ToLower().Contains("tell me more") && !string.IsNullOrEmpty(currentTopic))
            {
                Respond($"Since you're interested in {currentTopic}, here's more info...");
            }
            else
            {
                foreach (var keyword in keywordResponses.Keys)
                {
                    if (input.ToLower().Contains(keyword))
                    {
                        currentTopic = keyword;
                        Respond(keywordResponses[keyword]);
                        return;
                    }
                }
            }
        }

        static void HandleUnknownInput(string input)
        {
            Respond("I’m not sure I understand. Can you try rephrasing?");
        }
    }
}
