﻿using System;

namespace CybersecurityAwarenessBot.Models
{
    public class ActivityLogEntry
    {
        public DateTime Timestamp { get; set; }
        public string Description { get; set; }

        public override string ToString()
        {
            return $"{Timestamp:HH:mm} - {Description}";
        }
    }
}
