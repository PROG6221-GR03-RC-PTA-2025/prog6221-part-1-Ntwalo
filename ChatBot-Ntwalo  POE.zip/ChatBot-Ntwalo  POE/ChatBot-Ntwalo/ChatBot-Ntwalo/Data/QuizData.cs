﻿using System.Collections.Generic;
using CybersecurityAwarenessBot.Models;

namespace CybersecurityAwarenessBot.Data
{
    public static class QuizData
    {
        public static List<QuizQuestion> GetQuestions()
        {
            return new List<QuizQuestion>
            {
                new QuizQuestion
                {
                    Question = "What should you do if you receive a suspicious email?",
                    Options = new List<string> { "Reply immediately", "Click the link to investigate", "Report it as phishing", "Ignore it and delete it" },
                    CorrectIndex = 2,
                    Explanation = "Reporting phishing emails helps prevent future scams."
                },
                new QuizQuestion
                {
                    Question = "True or False: 'Password123' is a secure password.",
                    Options = new List<string> { "True", "False" },
                    CorrectIndex = 1,
                    Explanation = "Avoid common or simple passwords—they're easy to guess."
                },
                new QuizQuestion
                {
                    Question = "What is two-factor authentication?",
                    Options = new List<string> { "A backup login code", "A single password method", "A login step that requires two different verifications", "None of the above" },
                    CorrectIndex = 2,
                    Explanation = "2FA requires both a password and another form of identification—like a text code."
                },
                new QuizQuestion
                {
                    Question = "Which one is a common phishing tactic?",
                    Options = new List<string> { "Offering free gifts", "Using official-looking logos", "Pretending to be your boss", "All of the above" },
                    CorrectIndex = 3,
                    Explanation = "Phishing attacks often use urgency, authority, or enticing offers to trick users."
                },
                new QuizQuestion
                {
                    Question = "Why should you avoid using public Wi-Fi for banking?",
                    Options = new List<string> { "It's slow", "It can leak your location", "It's unencrypted and can expose your data", "It costs more data" },
                    CorrectIndex = 2,
                    Explanation = "Public Wi-Fi can be intercepted by attackers—always use a VPN if possible."
                },
                new QuizQuestion
                {
                    Question = "Which password is the most secure?",
                    Options = new List<string> { "Letmein123", "Pa$$w0rd", "D0gLover2023!", "Yt#7pX9@Lu1*" },
                    CorrectIndex = 3,
                    Explanation = "Strong passwords are long, random, and use mixed characters."
                },
                new QuizQuestion
                {
                    Question = "True or False: You should click unsubscribe on all spam emails.",
                    Options = new List<string> { "True", "False" },
                    CorrectIndex = 1,
                    Explanation = "Clicking links in spam emails can confirm your address to spammers. Delete instead."
                },
                new QuizQuestion
                {
                    Question = "Which of these is a social engineering method?",
                    Options = new List<string> { "Firewall blocking", "Data encryption", "Phishing", "Cookie tracking" },
                    CorrectIndex = 2,
                    Explanation = "Phishing is a type of social engineering where attackers manipulate people into revealing info."
                },
                new QuizQuestion
                {
                    Question = "How often should you update your passwords?",
                    Options = new List<string> { "Every 5 years", "Only after a breach", "Regularly, and especially if you suspect compromise", "Never" },
                    CorrectIndex = 2,
                    Explanation = "Updating your passwords often helps reduce your risk if one is leaked."
                },
                new QuizQuestion
                {
                    Question = "What should you check before logging into a website?",
                    Options = new List<string> { "The site's logo", "That it has HTTPS and a secure connection", "Whether it loads quickly", "Your antivirus software" },
                    CorrectIndex = 1,
                    Explanation = "Always check for HTTPS and the padlock symbol—these indicate a secure website."
                }
            };
        }
    }
}
