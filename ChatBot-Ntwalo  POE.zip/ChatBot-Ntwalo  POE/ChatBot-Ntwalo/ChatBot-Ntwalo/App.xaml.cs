﻿using System.Windows;
using static System.Net.Mime.MediaTypeNames;

namespace CybersecurityAwarenessBot
{
    public partial class App : Application
    {
    }
}
