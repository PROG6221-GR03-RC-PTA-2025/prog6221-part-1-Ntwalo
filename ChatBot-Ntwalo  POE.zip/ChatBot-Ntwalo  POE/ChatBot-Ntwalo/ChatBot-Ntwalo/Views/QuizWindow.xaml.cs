﻿using System.Collections.Generic;
using System.Windows;
using CybersecurityAwarenessBot.Models;
using CybersecurityAwarenessBot.Data;

namespace CybersecurityAwarenessBot.Views
{
    public partial class QuizWindow : Window
    {
        private List<QuizQuestion> questions;
        private int currentQuestionIndex = 0;
        private int score = 0;

        public QuizWindow()
        {
            InitializeComponent();
            questions = QuizData.GetQuestions();
            ShowQuestion();
        }

        private void ShowQuestion()
        {
            if (currentQuestionIndex >= questions.Count)
            {
                MessageBox.Show($"Quiz complete! Your score: {score}/{questions.Count}", "Quiz Result");

                string feedback = score >= 8
                    ? "Excellent work! You’re a cybersecurity pro!"
                    : score >= 5
                        ? "Good job! A little more practice and you'll be ready for anything."
                        : "Keep learning to stay safe online. Let’s review the key topics again soon.";

                MessageBox.Show(feedback, "Result Feedback");
                this.Close();
                return;
            }

            var q = questions[currentQuestionIndex];
            QuestionText.Text = q.Question;
            OptionsListBox.ItemsSource = q.Options;
            FeedbackText.Text = "";
            OptionsListBox.SelectedIndex = -1;
        }

        private void SubmitAnswer_Click(object sender, RoutedEventArgs e)
        {
            if (OptionsListBox.SelectedIndex == -1)
            {
                FeedbackText.Text = "Please select an answer.";
                return;
            }

            var q = questions[currentQuestionIndex];
            if (OptionsListBox.SelectedIndex == q.CorrectIndex)
            {
                score++;
                FeedbackText.Text = "✅ Correct! " + q.Explanation;
            }
            else
            {
                FeedbackText.Text = $"❌ Oops! {q.Explanation}";
            }

            currentQuestionIndex++;

            // Delay for user to read feedback
            Dispatcher.InvokeAsync(async () =>
            {
                await System.Threading.Tasks.Task.Delay(2000);
                ShowQuestion();
            });
        }
    }
}
