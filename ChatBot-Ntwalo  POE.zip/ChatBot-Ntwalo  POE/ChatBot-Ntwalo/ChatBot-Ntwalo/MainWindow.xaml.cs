﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Windows;
using System.Windows.Controls;
using CybersecurityAwarenessBot.Models;
using CybersecurityAwarenessBot.Views;
using CybersecurityAwarenessBot.Data;

namespace CybersecurityAwarenessBot
{
    public partial class MainWindow : Window
    {
        private List<TaskItem> tasks = new List<TaskItem>();
        private List<ActivityLogEntry> activityLog = new List<ActivityLogEntry>();
        private Dictionary<string, string> sentimentMap = new Dictionary<string, string>
        {
            { "worried", "It’s okay to feel worried. Let’s go through this together." },
            { "frustrated", "Cybersecurity can be tricky, but I'm here to make it easier." },
            { "curious", "Great! Curiosity is the first step to staying safe online." }
        };

        private Dictionary<string, string> keywordTips = new Dictionary<string, string>
        {
            { "password", "Use long, unique passwords for each account—try a password manager." },
            { "phishing", "Never click suspicious links. Hover over URLs to verify them." },
            { "privacy", "Review your app permissions and limit your personal info online." }
        };

        private string userName = "User";
        private string currentTopic = "";

        public MainWindow()
        {
            InitializeComponent();
            PlayWelcomeAudio();
            AddBotMessage("Welcome to the Cybersecurity Awareness Bot!");
            AddBotMessage("Type a message below to get started.");
        }

        private void PlayWelcomeAudio()
        {
            try
            {
                SoundPlayer player = new SoundPlayer("Resources/voice_greeting.wav");
                player.Play();
            }
            catch
            {
                AddBotMessage("(Voice greeting not available—check audio path.)");
            }
        }

        private void SendButton_Click(object sender, RoutedEventArgs e)
        {
            string input = UserInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(input)) return;

            AddUserMessage(input);
            ProcessInput(input.ToLower());

            UserInput.Text = "";
        }

        private void AddBotMessage(string message)
        {
            ChatOutput.Children.Add(new TextBlock
            {
                Text = $"Bot: {message}",
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 5, 0, 5)
            });
        }

        private void AddUserMessage(string message)
        {
            ChatOutput.Children.Add(new TextBlock
            {
                Text = $"You: {message}",
                FontWeight = FontWeights.Bold,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 5, 0, 5)
            });
        }

        private void ProcessInput(string input)
        {
            // Name intro
            if (input.StartsWith("my name is "))
            {
                userName = input.Replace("my name is ", "").Trim();
                AddBotMessage($"Nice to meet you, {userName}!");
                Log($"User name set to {userName}");
                return;
            }

            // NLP-style phrase detection
            if (input.Contains("remind me"))
            {
                var reminder = input.Replace("remind me to", "").Trim();
                var task = new TaskItem
                {
                    Title = reminder,
                    Description = $"Reminder: {reminder}",
                    ReminderDate = DateTime.Now.AddDays(1)
                };
                tasks.Add(task);
                AddBotMessage($"Reminder set for '{reminder}' tomorrow.");
                Log($"Reminder added: {reminder}");
                return;
            }

            if (input.Contains("add task"))
            {
                var title = input.Replace("add task", "").Trim();
                tasks.Add(new TaskItem
                {
                    Title = title,
                    Description = $"Task: {title}"
                });
                AddBotMessage($"Task added: '{title}'. Want me to remind you later?");
                Log($"Task added: {title}");
                return;
            }

            if (input.Contains("show tasks"))
            {
                if (tasks.Count == 0)
                {
                    AddBotMessage("You don’t have any tasks yet.");
                    return;
                }

                AddBotMessage("Here are your tasks:");
                foreach (var task in tasks)
                {
                    AddBotMessage($"• {task}");
                }
                return;
            }

            if (input.Contains("show log"))
            {
                AddBotMessage("Here’s your recent activity:");
                foreach (var entry in activityLog.TakeLast(10))
                {
                    AddBotMessage(entry.ToString());
                }
                return;
            }

            if (input.Contains("start quiz"))
            {
                var quizWindow = new QuizWindow();
                quizWindow.Show();
                Log("Quiz started");
                return;
            }

            // Keyword tips
            foreach (var keyword in keywordTips.Keys)
            {
                if (input.Contains(keyword))
                {
                    AddBotMessage(keywordTips[keyword]);
                    currentTopic = keyword;
                    Log($"User asked about {keyword}");
                    return;
                }
            }

            // Sentiment
            foreach (var mood in sentimentMap.Keys)
            {
                if (input.Contains(mood))
                {
                    AddBotMessage(sentimentMap[mood]);
                    Log($"Detected sentiment: {mood}");
                    return;
                }
            }

            if (input.Contains("tell me more") && !string.IsNullOrEmpty(currentTopic))
            {
                AddBotMessage($"Here’s more about {currentTopic}: {keywordTips[currentTopic]}");
                Log($"User asked for more on {currentTopic}");
                return;
            }

            AddBotMessage("I'm not sure I understand. Try rephrasing or ask about phishing, passwords, or privacy.");
        }

        private void Log(string description)
        {
            activityLog.Add(new ActivityLogEntry
            {
                Timestamp = DateTime.Now,
                Description = description
            });
        }
    }
}
